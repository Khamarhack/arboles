#include <bits/stdc++.h>
#include "quadtree.h"

using namespace std;

int main(){

}
